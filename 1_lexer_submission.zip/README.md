# 1_Lexer

Compile:  make

run:      ./lexer [params] [file]

Example:  ./lexer --source --clean input.pl0
